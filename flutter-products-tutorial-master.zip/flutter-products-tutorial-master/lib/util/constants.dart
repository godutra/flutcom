class Constants {
  static const String ROUTE_PRODUCT_DETAIL = "/productDetail";
}