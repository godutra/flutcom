class AnyImage {
  int id;
  String imageDescription;
  String imageURL;
  String title;
  String alt;

  AnyImage({
    this.id,
    this.imageDescription,
    this.imageURL,
    this.alt,
    this.title,
  });
}
